#!/bin/bash
dotnet WebJob1/bin/Debug/net9.0/win-x64/WebJob1.dll
